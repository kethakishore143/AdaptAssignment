.App-container {
  display: flex;
  flex-direction: row;
}

.order-container {
  display: flex;
  flex-direction: column;
  width: 100%;
}

.tabs-container {
  display: flex;
  flex-direction: row;
  align-items: center;
  width: 100%;
}

.tabs-container li {
  padding: 10px;
  margin-left: 20px;
}

.tabs-container p {
  padding: 20px;

  color: black;
  font-size: 15px;
  font-weight: bold;
}

.order-close {
  display: flex;
  justify-content: center;
  align-items: center;
}

.order-close {
  padding: 10px;
}

.order-close-container {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  margin: 20px;
}

.transactions-table-container {
  height: 100%;
  border-radius: 8px;
}

.transactions-table {
  padding-left: 0;
  margin: 0px;
}

.table-header {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  height: 48px;
  list-style-type: none;
  border: 1px solid #cbd5e1;
  padding-left: 10px;
  padding-right: 10px;
}

@media screen and (min-width: 768px) {
  .table-header {
    padding-left: 24px;
    padding-right: 24px;
  }
}

.table-header-cell {
  color: #334155;
  font-family: "Roboto";
  font-size: 12px;
  font-weight: 500;
  width: 30%;
  border-right: none;
}

@media screen and (min-width: 768px) {
  .table-header-cell {
    font-size: 16px;
  }
}

.transactions-table-container p {
  font-size: 15px;
  font-weight: bold;
  font-family: roboto;
  padding: 10px;
}

.quetation {
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
}

.quetation p {
  padding: 20px;
  border: 1px solid lightgray;
  margin: 10px;
}

.displayItem {
  display: flex;
}

.Hide-Item {
  display: none;
}

.buttons-container {
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
}

.page-count {
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  align-items: center;
}

.page-count p {
  border: 1px solid lightgray;
  padding: 10px;
  margin: 10px;
}
