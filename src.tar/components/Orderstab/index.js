import { Component } from "react";
import Navigationbar from "../Navigationbar";
import Ordertable from "../Ordertable";
import { IoClose, IoSettingsOutline } from "react-icons/io5";

import "./index.css";

const orderDetails = [
  {
    Add: "+",
    channelimgUrl:
      "https://assets.ccbp.in/frontend/react-js/money-manager/balance-image.png",
    orderNo: "#TKN20203754",
    orderDate: "2022-05-04",
    city: "Luknow",
    customerName: "Abhishek Dixit",
    orderValue: "00.00",
    status: "pending",
    operation: "Active",
  },
  {
    Add: "+",
    channelimgUrl:
      "https://assets.ccbp.in/frontend/react-js/money-manager/balance-image.png",
    orderNo: "#TKN20203754",
    orderDate: "2022-05-04",
    city: "Luknow",
    customerName: "Abhishek Dixit",
    orderValue: "00.00",
    status: "pending",
    operation: "Active",
  },
  {
    Add: "+",
    channelimgUrl:
      "https://assets.ccbp.in/frontend/react-js/money-manager/balance-image.png",
    orderNo: "#TKN20203754",
    orderDate: "2022-05-04",
    city: "Luknow",
    customerName: "Abhishek Dixit",
    orderValue: "00.00",
    status: "pending",
    operation: "Active",
  },
];

class Orderstab extends Component {
  render() {
    return (
      <div>
        <Navigationbar />
        <div className="order-close-container">
          <div className="order-close">
            <p>Orders</p>
            <IoClose />
          </div>

          <IoSettingsOutline />
        </div>
        <ul className="tabs-container">
          <li>
            <a href="#">Pending</a>
          </li>
          <li>
            <a href="#">Accepted</a>
          </li>
          <li>
            <a href="#">AWB Created</a>
          </li>
          <li>
            <a href="#">AWB Created</a>
          </li>
          <li>
            <a href="#">Ready to Ship</a>
          </li>
          <li>
            <a href="#">Shipped</a>
          </li>

          <li>
            <a href="#">Completed</a>
          </li>
          <li>
            <a href="#">Cancelled</a>
          </li>
        </ul>

        <ul className="order-container">
          <div className="quetation">
            <p>Import Oreders</p>
            <p>Accept</p>
            <p>Print</p>
          </div>
          <div className="transactions-table-container">
            <ul className="transactions-table">
              <li className="table-header">
                <p className="table-header-cell">Import Orders</p>
                <p className="table-header-cell">Channel</p>
                <p className="table-header-cell">Order No</p>
                <p className="table-header-cell">Order Date</p>
                <p className="table-header-cell">City</p>
                <p className="table-header-cell">Customer Name</p>
                <p className="table-header-cell">Order Value</p>
                <p className="table-header-cell">Status</p>
                <p className="table-header-cell">Operation</p>
              </li>
            </ul>
          </div>
          {orderDetails.map((eachItem) => (
            <Ordertable orderData={eachItem} />
          ))}
        </ul>
      </div>
    );
  }
}

export default Orderstab;
