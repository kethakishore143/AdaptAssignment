import Orderstab from "./components/Orderstab";
import "./App.css";

function App() {
  return (
    <div className="App">
      <Orderstab />
    </div>
  );
}

export default App;
